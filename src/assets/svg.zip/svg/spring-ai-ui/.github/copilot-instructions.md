# Spring AI UI - Copilot Instructions

This document provides essential context for AI agents working with the Spring AI UI frontend codebase.

## Project Architecture

This is a lightweight frontend application that interfaces with a Spring Boot AI backend. The architecture follows these key patterns:

- **Single Page Application**: Simple HTML/CSS/JS structure without a build system
- **RESTful Integration**: Communicates with backend at `http://localhost:8080/api/ask`
- **Error Handling**: Includes user feedback for connection and validation issues

## Key Files

- `index.html`: Main entry point and UI structure
- `script.js`: Core application logic and API integration
- `style.css`: Modern, gradient-based UI styling with responsive design

## Communication Patterns

### Backend Integration
```javascript
// API call pattern for AI requests
fetch("http://localhost:8080/api/ask", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ prompt })
})
```

### Response Format
Backend responses are expected in the format:
```json
{
  "answer": "AI-generated response string"
}
```

## UI/UX Patterns

- **Loading States**: Use "⏳ Thinking..." for API requests in progress
- **Error States**: Use emojis for errors (e.g., "❌" for connection errors, "⚠️" for validation)
- **Styling**: Use Poppins font family and indigo-based color scheme
- **Animations**: Subtle hover effects on interactive elements

## Development Workflow

1. Serve the frontend using any static file server
2. Ensure Spring Boot backend is running on port 8080
3. Access application through web browser at your local server address

## Testing

Manual testing focus areas:
- Empty input validation
- Backend connection error handling
- Response rendering in the UI